package com.example.personalvideovault

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.DateFormat
import java.util.Date
import java.util.Locale

data class VaultVideo(
    val id: String,
    val name: String,
    val fileName: String,
    val size: Long,
    val importedAt: Long,
    val sourceUri: String? = null,
    val verified: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vaultDir = File(filesDir, "vault_videos").apply { mkdirs() }
        setContent {
            MaterialTheme {
                VaultApp(
                    vaultDir = vaultDir,
                    metadataFile = File(filesDir, "vault_index.json"),
                    resolver = contentResolver
                )
            }
        }
    }
}

@Composable
private fun VaultApp(vaultDir: File, metadataFile: File, resolver: ContentResolver) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("vault_security", 0) }
    var pinHash by remember { mutableStateOf(prefs.getString("pin_hash", null)) }
    var unlocked by remember { mutableStateOf(pinHash == null) }
    var pinEntry by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var videos by remember { mutableStateOf(loadIndex(metadataFile)) }
    var playing by remember { mutableStateOf<VaultVideo?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                message = "Importing ${uris.size} video(s)…"
                var ok = 0
                for (uri in uris) {
                    try {
                        val imported = withContext(Dispatchers.IO) {
                            importVideo(resolver, uri, vaultDir)
                        }
                        videos = videos + imported
                        saveIndex(metadataFile, videos)
                        ok++
                    } catch (e: Exception) {
                        message = "Import failed: ${e.message ?: "unknown error"}. Original kept."
                    }
                }
                busy = false
                if (ok > 0) message = "Imported and verified $ok video(s). Original files were not deleted."
            }
        }
    }

    if (!unlocked) {
        Scaffold { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Lock, null, modifier = Modifier.size(48.dp))
                Text("My Personal Video Vault", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(12.dp))
                Text("Enter your PIN")
                OutlinedTextField(
                    value = pinEntry,
                    onValueChange = { pinEntry = it.filter(Char::isDigit).take(12) },
                    label = { Text("PIN") },
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    if (hash(pinEntry) == pinHash) {
                        unlocked = true
                        pinEntry = ""
                    } else message = "Incorrect PIN"
                }) { Text("Unlock") }
                if (message.isNotBlank()) Text(message)
            }
        }
        return
    }

    if (pinHash == null) {
        Scaffold { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Create a vault PIN", style = MaterialTheme.typography.headlineSmall)
                Text("This starter uses a local PIN check. It does not encrypt the video files.")
                OutlinedTextField(
                    value = pinEntry, onValueChange = { pinEntry = it.filter(Char::isDigit).take(12) },
                    label = { Text("New PIN (4–12 digits)") },
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = pinConfirm, onValueChange = { pinConfirm = it.filter(Char::isDigit).take(12) },
                    label = { Text("Confirm PIN") },
                    visualTransformation = PasswordVisualTransformation()
                )
                Button(onClick = {
                    if (pinEntry.length < 4) message = "Use at least 4 digits"
                    else if (pinEntry != pinConfirm) message = "PINs do not match"
                    else {
                        val h = hash(pinEntry)
                        prefs.edit().putString("pin_hash", h).apply()
                        pinHash = h
                        pinEntry = ""; pinConfirm = ""
                        message = "PIN created"
                    }
                }) { Text("Save PIN") }
                if (message.isNotBlank()) Text(message)
            }
        }
        return
    }

    val used = videos.sumOf { it.size }
    val target = 512L * 1024 * 1024 * 1024
    val usable = vaultDir.usableSpace

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Personal Video Vault") },
                actions = {
                    IconButton(onClick = { unlocked = false; playing = null }) {
                        Icon(Icons.Default.Lock, contentDescription = "Lock vault")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { picker.launch(arrayOf("video/*")) },
                icon = { Icon(Icons.Default.VideoLibrary, null) },
                text = { Text("Import videos") },
                expanded = true
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Text("Stored: ${formatBytes(used)} / 512 GB target")
            Text("Free space on device: ${formatBytes(usable)}")
            LinearProgressIndicator(
                progress = { (used.toDouble() / target).coerceIn(0.0, 1.0).toFloat() },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            Text("Offline storage • Imported files stay in this app's private storage")
            if (busy) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (message.isNotBlank()) {
                Text(message, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            if (playing != null) {
                Text("Now playing: ${playing!!.name}", style = MaterialTheme.typography.titleMedium)
                VideoPlayer(File(vaultDir, playing!!.fileName))
                TextButton(onClick = { playing = null }) { Text("Close player") }
            }
            if (videos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No videos yet. Tap Import videos to begin.")
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
                    items(videos, key = { it.id }) { video ->
                        ListItem(
                            headlineContent = { Text(video.name, maxLines = 2) },
                            supportingContent = {
                                Text("${formatBytes(video.size)} • ${if (video.verified) "Verified copy" else "Not verified"}")
                            },
                            leadingContent = { Icon(Icons.Default.PlayArrow, null) },
                            modifier = Modifier.clickable {
                                val file = File(vaultDir, video.fileName)
                                if (file.exists()) playing = video
                                else message = "Stored file is missing. Original was not touched."
                            },
                            trailingContent = {
                                IconButton(onClick = {
                                    val file = File(vaultDir, video.fileName)
                                    if (file.delete()) {
                                        videos = videos.filterNot { it.id == video.id }
                                        saveIndex(metadataFile, videos)
                                        if (playing?.id == video.id) playing = null
                                        message = "Vault copy deleted."
                                    } else message = "Could not delete vault copy."
                                }) { Icon(Icons.Default.Delete, contentDescription = "Delete vault copy") }
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoPlayer(file: File) {
    val context = LocalContext.current
    val player = remember(file.absolutePath) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(240.dp)
    )
}

private fun importVideo(resolver: ContentResolver, uri: Uri, vaultDir: File): VaultVideo {
    val displayName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: "video_${System.currentTimeMillis()}.mp4"

    val id = java.util.UUID.randomUUID().toString()
    val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "video.mp4" }
    val temp = File(vaultDir, "$id.tmp")
    val finalFile = File(vaultDir, "${id}_$safeName")
    val sourceHash = MessageDigest.getInstance("SHA-256")
    val copiedHash = MessageDigest.getInstance("SHA-256")
    var copied = 0L

    resolver.openInputStream(uri)?.use { input ->
        FileOutputStream(temp).use { output ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                output.write(buffer, 0, count)
                sourceHash.update(buffer, 0, count)
                copied += count.toLong()
            }
            output.fd.sync()
        }
    } ?: throw IllegalStateException("Could not open selected video")

    FileInputStream(temp).use { input ->
        val buffer = ByteArray(1024 * 1024)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            copiedHash.update(buffer, 0, count)
        }
    }

    if (temp.length() != copied || !sourceHash.digest().contentEquals(copiedHash.digest())) {
        temp.delete()
        throw IllegalStateException("Verification failed")
    }
    if (!temp.renameTo(finalFile)) {
        temp.copyTo(finalFile, overwrite = true)
        temp.delete()
    }
    return VaultVideo(
        id = id,
        name = displayName,
        fileName = finalFile.name,
        size = finalFile.length(),
        importedAt = System.currentTimeMillis(),
        sourceUri = uri.toString(),
        verified = true
    )
}

private fun loadIndex(file: File): List<VaultVideo> {
    if (!file.exists()) return emptyList()
    return try {
        val array = JSONArray(file.readText())
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            VaultVideo(
                id = o.optString("id"),
                name = o.optString("name"),
                fileName = o.optString("fileName"),
                size = o.optLong("size"),
                importedAt = o.optLong("importedAt"),
                sourceUri = o.optString("sourceUri").takeIf { it.isNotBlank() && it != "null" },
                verified = o.optBoolean("verified")
            )
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveIndex(file: File, videos: List<VaultVideo>) {
    val array = JSONArray()
    videos.forEach { v ->
        array.put(JSONObject().apply {
            put("id", v.id); put("name", v.name); put("fileName", v.fileName)
            put("size", v.size); put("importedAt", v.importedAt)
            put("sourceUri", v.sourceUri); put("verified", v.verified)
        })
    }
    file.writeText(array.toString())
}

private fun hash(value: String): String =
    MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = -1
    do { value /= 1024.0; unit++ } while (value >= 1024 && unit < units.lastIndex)
    return String.format(Locale.US, "%.2f %s", value, units[unit])
}
