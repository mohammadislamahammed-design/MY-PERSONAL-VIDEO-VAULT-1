# My Personal Video Vault (starter project)

A native Kotlin/Jetpack Compose Android project intended as a starting point for an offline video vault.

## Important limitations in this starter
- This project source has not been built or tested on a physical Android device in this environment.
- It copies complete video files into the app's private internal storage and verifies the copied bytes with SHA-256.
- It does **not** automatically delete original files. That is intentional: the original-deletion flow needs Android's system confirmation UI and further device testing before it is safe to enable.
- The PIN is a basic local gate, not a complete security solution. The video files are not encrypted in this starter.
- Metadata is stored in a JSON index for simplicity; production use should migrate to Room and add robust crash recovery.
- The 512 GB figure is a target, not newly created capacity. Actual capacity is limited by free internal storage.
- Playback support depends on Android device codecs.
- No APK is included because an APK must be built and verified using an Android SDK/Gradle environment.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to sync and install any required Android SDK components.
3. Run the app on a test device first.
4. To build a debug APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Test imports with expendable sample videos before moving important files.

## Safety
Do not delete original videos until you have tested the imported copy and verified playback. Uninstalling the app or clearing its app data may delete vault videos.
